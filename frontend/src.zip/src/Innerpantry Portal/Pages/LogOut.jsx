import React from "react";
import { useNavigate } from "react-router-dom";
import './styles/Logout.css';

const Logout = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear user session data (e.g., token)
    localStorage.removeItem("authToken"); // Assuming the token is stored in localStorage
    sessionStorage.clear(); // Clear session storage if used
    alert("You have been logged out!");
    navigate("/"); // Redirect to the login page
  };

  return (
    <div className="logout-container">
      <button onClick={handleLogout} className="logout-button">
        Log Out
      </button>
    </div>
  );
};

export default Logout;
