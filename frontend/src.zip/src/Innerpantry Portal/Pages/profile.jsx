import React, { useState, useEffect } from 'react';
import apiClient from "../../utils/axiosConfig"; // Make sure axiosConfig is properly set up
import './styles/Profile.css';  // Import the CSS file


const PantryStaffDashboard = () => {
  const [pantryStaff, setPantryStaff] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch pantry staff details on component mount
  useEffect(() => {
    // Get the JWT token (this may be stored in localStorage or state)
    const token = localStorage.getItem('token'); // Adjust according to where your token is stored

    if (token) {
      apiClient.get('/api/pantry-staff/me', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })
        .then(response => {
          setPantryStaff(response.data.pantryStaff);
          setLoading(false);
        })
        .catch(err => {
          setError(err.response ? err.response.data.message : 'An error occurred');
          setLoading(false);
        });
    } else {
      setError('No token found');
      setLoading(false);
    }
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  return (
    <div>
      <h1>Pantry Staff Dashboard</h1>
      <div>
        <h2>{pantryStaff.name}</h2>
        <p>Email: {pantryStaff.email}</p>
        <p>Contact Info: {pantryStaff.contactInfo}</p>
        <p>Role: {pantryStaff.role}</p>
      </div>
    </div>
  );
};

export default PantryStaffDashboard;
