import React, { useState, useEffect } from "react";
import axios from "axios";
import './styles/DietChartManagement.css'

const DietChartManagement = () => {
  const [patients, setPatients] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [dietChart, setDietChart] = useState({
    morningMeal: "",
    eveningMeal: "",
    nightMeal: "",
  });

  // Fetch patients from the backend
  const fetchPatients = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/patients"); // Replace with your backend URL
      setPatients(response.data);
    } catch (error) {
      console.error("Error fetching patients:", error);
    }
  };

  // Fetch patient diet chart from the backend
  const fetchDietChart = async (patientId) => {
    try {
      const response = await axios.get(`http://localhost:5000/api/dietCharts/${patientId}`);
      setDietChart(response.data);
    } catch (error) {
      console.error("Error fetching diet chart:", error);
    }
  };

  // Handle selecting a patient
  const handlePatientSelect = (patientId) => {
    setSelectedPatient(patientId);
    fetchDietChart(patientId);
  };

  // Handle form input change for diet chart
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setDietChart((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // Handle saving the diet chart
  const handleSave = async () => {
    try {
      await axios.put(`http://localhost:5000/api/dietCharts/${selectedPatient}`, dietChart);
      alert("Diet chart updated successfully!");
    } catch (error) {
      console.error("Error saving diet chart:", error);
    }
  };

  // Fetch patients when component mounts
  useEffect(() => {
    fetchPatients();
  }, []);

  return (
    <div className="diet-chart-management">
      <h2>Diet Chart Management</h2>
      <div className="patient-selection">
        <label>Select Patient:</label>
        <select onChange={(e) => handlePatientSelect(e.target.value)}>
          <option value="">--Select Patient--</option>
          {patients.map((patient) => (
            <option key={patient.id} value={patient.id}>
              {`Room: ${patient.roomNumber} - Bed: ${patient.bedNumber}`}
            </option>
          ))}
        </select>
      </div>

      {selectedPatient && (
        <div className="diet-chart-form">
          <h3>Diet Chart for Patient</h3>
          <form onSubmit={(e) => e.preventDefault()}>
            <div>
              <label>Morning Meal:</label>
              <input
                type="text"
                name="morningMeal"
                value={dietChart.morningMeal}
                onChange={handleInputChange}
                placeholder="Enter morning meal details"
              />
            </div>
            <div>
              <label>Evening Meal:</label>
              <input
                type="text"
                name="eveningMeal"
                value={dietChart.eveningMeal}
                onChange={handleInputChange}
                placeholder="Enter evening meal details"
              />
            </div>
            <div>
              <label>Night Meal:</label>
              <input
                type="text"
                name="nightMeal"
                value={dietChart.nightMeal}
                onChange={handleInputChange}
                placeholder="Enter night meal details"
              />
            </div>
            <button type="button" onClick={handleSave}>
              Save Diet Chart
            </button>
          </form>
        </div>
      )}
    </div>
  );
};

export default DietChartManagement;
