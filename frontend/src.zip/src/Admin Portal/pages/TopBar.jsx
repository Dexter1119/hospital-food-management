import React from "react";

const TopBar = () => {
  return (
    <div className="flex items-center justify-between bg-gray-800 text-white p-4">
      <div className="flex items-center gap-4">
        <input
          type="text"
          placeholder="Search..."
          className="p-2 border border-gray-300 rounded"
        />
        <button className="bg-green-600 text-white py-2 px-4 rounded">Search</button>
      </div>

      <div className="flex items-center gap-4">
        <button className="text-white">Notifications</button>
        <button className="text-white">Profile</button>
      </div>
    </div>
  );
};

export default TopBar;
