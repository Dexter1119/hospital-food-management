import React, { useEffect } from "react";
import { useHistory } from "react-router-dom"; // If using React Router for routing

const LogoutPage = () => {
    const history = useHistory();

    // Handle the logout process
    useEffect(() => {
        // Remove authentication token or clear session storage
        localStorage.removeItem("authToken"); // Or any other token/session key
        sessionStorage.removeItem("authToken"); // If using session storage
        alert("You have logged out successfully!");

        // Redirect to login page after 2 seconds
        setTimeout(() => {
            history.push("/adminLogin"); // Redirect to the login page
        }, 2000);
    }, [history]);

    return (
        <div className="logout-page-container">
            <h2>You have been logged out</h2>
            <p>Redirecting to the login page...</p>
        </div>
    );
};

export default LogoutPage;
